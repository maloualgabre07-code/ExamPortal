const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const bcrypt=require('bcryptjs');
const {createApp}=require('../app');
const {testPool}=require('./test-db');

class EventTargetMock{
 constructor(){this.listeners=new Map();}
 addEventListener(type,handler){const handlers=this.listeners.get(type)||new Set();handlers.add(handler);this.listeners.set(type,handlers);}
 removeEventListener(type,handler){this.listeners.get(type)?.delete(handler);}
 dispatch(type,event={}){for(const handler of this.listeners.get(type)||[])handler(event);}
}

class ElementMock extends EventTargetMock{
 constructor(tag){super();this.tagName=tag;this.children=[];this.attributes={};this.parent=null;this.hidden=false;this.className='';this.textContent='';}
 setAttribute(name,value){this.attributes[name]=value;}
 appendChild(child){child.parent=this;this.children.push(child);return child;}
 append(...children){for(const child of children)this.appendChild(child);}
 remove(){if(!this.parent)return;this.parent.children=this.parent.children.filter(child=>child!==this);this.parent=null;}
}

test('active exam guard renders watermark, obscures inactive tabs, and leaves answers untouched',()=>{
 const document=new EventTargetMock();
 document.hidden=false;
 document.body=new ElementMock('body');
 document.createElement=tag=>new ElementMock(tag);
 const window=new EventTargetMock();
 window.document=document;
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../public/exam-guard.js'),'utf8'),{window,console});

 const answers={question1:1};
 const timer={running:true};
 const events=[];
 window.ExamGuard.start({name:'Student Example',onEvent:event=>events.push(event)});
 const watermark=document.body.children.find(element=>element.className==='exam-watermark');
 const overlay=document.body.children.find(element=>element.className==='exam-obscured');
 assert.ok(watermark);
 assert.equal(watermark.attributes['aria-hidden'],'true');
 assert.equal(watermark.children.length,12);
 assert.ok(watermark.children.every(label=>label.textContent==='Student Example'));
 assert.equal(overlay.hidden,true);

 document.hidden=true;
 document.dispatch('visibilitychange');
 assert.equal(overlay.hidden,false);
 document.hidden=false;
 document.dispatch('visibilitychange');
 assert.equal(overlay.hidden,true);
 window.dispatch('blur');
 assert.equal(overlay.hidden,false);
 window.dispatch('focus');
 assert.equal(overlay.hidden,true);

 let prevented=false,stopped=false;
 document.dispatch('keydown',{key:'PrintScreen',preventDefault(){prevented=true;},stopPropagation(){stopped=true;}});
 assert.equal(prevented,true);
 assert.equal(stopped,true);
 prevented=false;stopped=false;
 document.dispatch('keydown',{key:'a',preventDefault(){prevented=true;},stopPropagation(){stopped=true;}});
 assert.equal(prevented,false);
 assert.equal(stopped,false);
 assert.deepEqual(events,['tab_hidden','focus_lost']);
 assert.deepEqual(answers,{question1:1});
 assert.equal(timer.running,true);

 window.ExamGuard.stop();
 assert.equal(document.body.children.length,0);
});

test('authenticated students can record active-tab events and submit normally without SEB',async t=>{
 const previous=process.env.SEB_REQUIRED;
 process.env.SEB_REQUIRED='false';
 const pool=await testPool();
 let service,server;
 t.after(async()=>{
  if(service)service.close();
  if(server)await new Promise(resolve=>server.close(resolve));
  await pool.end();
  if(previous===undefined)delete process.env.SEB_REQUIRED;
  else process.env.SEB_REQUIRED=previous;
 });
 await pool.exec(fs.readFileSync(path.join(__dirname,'../schema.sql'),'utf8'));
 const passwordHash=await bcrypt.hash('TestPass123!',4);
 for(const[name,email,role]of [
  ['Teacher','teacher@example.test','instructor'],
  ['Student','student@example.test','student'],
  ['Other Student','other@example.test','student']
 ])await pool.query('INSERT INTO users(full_name,email,password_hash,role) VALUES($1,$2,$3,$4)',[name,email,passwordHash,role]);

 service=createApp(pool,'testing-secret-that-is-more-than-32-characters');
 server=service.app.listen(0,'127.0.0.1');
 await new Promise(resolve=>server.once('listening',resolve));
 const base=`http://127.0.0.1:${server.address().port}/api`;
 function client(){
  let cookie='',csrf='';
  return{
   async call(route,method='GET',body){
    const headers={Cookie:cookie};
    if(method!=='GET'){headers['Content-Type']='application/json';headers['X-CSRF-Token']=csrf;}
    const response=await fetch(base+route,{method,headers,...(method==='GET'?{}:{body:JSON.stringify(body??{})})});
    const setCookie=response.headers.get('set-cookie');
    if(setCookie)cookie=setCookie.split(';')[0];
    const data=await response.json();
    if(data.token)csrf=data.token;
    return{status:response.status,...data};
   },
   async login(email){
    await this.call('/csrf');
    const result=await this.call('/login','POST',{email,password:'TestPass123!'});
    assert.equal(result.status,200);
   }
  };
 }

 const teacher=client(),student=client(),other=client();
 await teacher.login('teacher@example.test');
 await student.login('student@example.test');
 await other.login('other@example.test');
 const group=await teacher.call('/classes','POST',{name:'Browser Exam Group'});
 assert.equal(group.status,201);
 assert.equal((await student.call('/classes/join','POST',{code:group.class.join_code})).status,201);
 const created=await teacher.call('/exams','POST',{
  title:'Browser Exam',description:'Normal Chrome workflow',duration_minutes:15,passing_score:50,max_attempts:1
 });
 assert.equal(created.status,201);
 const examId=created.exam.id;
 assert.equal((await teacher.call(`/exams/${examId}/audience`,'PUT',{class_only:true,class_ids:[group.class.id]})).status,200);
 assert.equal((await teacher.call(`/exams/${examId}/questions`,'POST',{
  prompt:'Choose the correct option.',options:['Correct','Incorrect'],correct_index:0,points:1
 })).status,201);
 assert.equal((await teacher.call(`/exams/${examId}/status`,'POST',{status:'published'})).status,200);

 const started=await student.call(`/exams/${examId}/start`,'POST');
 assert.equal(started.status,200);
 const attemptId=started.attempt.id;
 const questionId=started.attempt.questions[0].id;
 const deadline=started.attempt.deadline_at;
 const answers={[questionId]:0};
 assert.equal((await student.call(`/attempts/${attemptId}/answers`,'PUT',{answers})).status,200);
 assert.equal((await student.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'tab_hidden'})).status,202);
 assert.equal((await student.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'focus_lost'})).status,202);
 assert.equal((await student.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'keystroke'})).status,400);
 assert.equal((await other.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'tab_hidden'})).status,403);
 assert.equal((await teacher.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'tab_hidden'})).status,403);
 const resumed=await student.call(`/attempts/${attemptId}`);
 assert.equal(resumed.attempt.deadline_at,deadline);
 assert.deepEqual(resumed.attempt.answers,answers);
 for(let i=0;i<10;i++)assert.equal((await student.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'tab_hidden'})).status,202);
 assert.equal((await student.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'tab_hidden'})).status,429);
 const logged=(await pool.query("SELECT details FROM exam_audit WHERE action='attempt.integrity' ORDER BY id")).rows;
 assert.deepEqual(logged.map(row=>row.details),[
  `${attemptId}: tab_hidden`,`${attemptId}: focus_lost`,...Array(10).fill(`${attemptId}: tab_hidden`)
 ]);
 const submitted=await student.call(`/attempts/${attemptId}/submit`,'POST',{answers});
 assert.equal(submitted.status,200);
 assert.equal(submitted.attempt.score,1);
 assert.equal(submitted.attempt.status,'submitted');
 assert.equal((await student.call(`/attempts/${attemptId}/integrity-event`,'POST',{event:'tab_hidden'})).status,409);
});
