const path = require("path");
const nodemailer = require("nodemailer");

require("dotenv").config({
  path: path.join(__dirname, "../.env"),
  quiet: true,
});

async function checkGmail() {
  const user = (process.env.GMAIL_USER || "").trim();
  const pass = (process.env.GMAIL_APP_PASSWORD || "").replace(/\s/g, "");

  if (!/^[^\s@]+@gmail\.com$/i.test(user) || pass.length !== 16) {
    console.error(
      "Set GMAIL_USER and a 16-character Gmail App Password in your local .env."
    );
    process.exitCode = 1;
    return;
  }

  const transport = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user, pass },
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 20000,
    logger: false,
    debug: false,
  });

  try {
    await transport.verify();
    console.log("Gmail connection and authentication succeeded.");
    console.log("This check did not send an email.");
  } catch (error) {
    console.error("Error code:", error.code || "UNKNOWN");
    console.error("SMTP status:", error.responseCode || "NONE");

    const command = String(error.command || "NONE");
    console.error(
      "Command:",
      command.startsWith("AUTH") ? "AUTH" : command
    );

    process.exitCode = 1;
  } finally {
    transport.close();
  }
}

checkGmail();