'use strict';
(()=>{
 let cleanup=null;

 function stop(){
  if(cleanup){cleanup();cleanup=null;}
 }

 function start({name,onEvent}={}){
  stop();
  const {document}=window;
  if(!document?.body)return;

  const watermark=document.createElement('div');
  watermark.className='exam-watermark';
  watermark.setAttribute('aria-hidden','true');
  for(let i=0;i<12;i++){
   const label=document.createElement('span');
   label.textContent=name||'ExamPortal student';
   watermark.appendChild(label);
  }

  const obscured=document.createElement('div');
  obscured.className='exam-obscured';
  obscured.hidden=true;
  obscured.setAttribute('role','status');
  obscured.setAttribute('aria-live','polite');
  const message=document.createElement('p');
  message.textContent='Examination paused while this tab is inactive. Return to this window to continue; the timer keeps running.';
  obscured.appendChild(message);
  document.body.append(watermark,obscured);

  let documentHidden=Boolean(document.hidden),windowBlurred=false;
  const updateOverlay=()=>{obscured.hidden=!(documentHidden||windowBlurred);};
  const report=event=>{
   try{
    const result=onEvent?.(event);
    if(result?.catch)result.catch(error=>console.warn('ExamPortal activity event was not recorded:',error));
   }catch(error){console.warn('ExamPortal activity event was not recorded:',error);}
  };
  const onVisibilityChange=()=>{
   if(document.hidden){
    if(!documentHidden)report('tab_hidden');
    documentHidden=true;
   }else documentHidden=false;
   updateOverlay();
  };
  const onBlur=()=>{
   if(!windowBlurred)report('focus_lost');
   windowBlurred=true;
   updateOverlay();
  };
  const onFocus=()=>{
   windowBlurred=false;
   updateOverlay();
  };
  const onKeyDown=event=>{
   const key=String(event.key||'').toLowerCase();
   const screenshotShortcut=event.key==='PrintScreen'||
    ((event.metaKey||event.ctrlKey)&&event.shiftKey&&['3','4','5','s'].includes(key));
   if(screenshotShortcut){
    event.preventDefault();
    event.stopPropagation();
   }
  };

  document.addEventListener('visibilitychange',onVisibilityChange);
  document.addEventListener('keydown',onKeyDown,true);
  window.addEventListener('blur',onBlur);
  window.addEventListener('focus',onFocus);
  updateOverlay();
  cleanup=()=>{
   document.removeEventListener('visibilitychange',onVisibilityChange);
   document.removeEventListener('keydown',onKeyDown,true);
   window.removeEventListener('blur',onBlur);
   window.removeEventListener('focus',onFocus);
   watermark.remove();
   obscured.remove();
  };
 }

 window.ExamGuard={start,stop};
})();
