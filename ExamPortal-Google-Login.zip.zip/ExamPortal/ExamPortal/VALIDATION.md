# Validation

- JavaScript syntax: backend and frontend checked with node --check.
- Integration: complete assessment flow passed against an isolated PGlite PostgreSQL engine. The runtime pg/PostgreSQL connection on the user's Windows machine still needs the installation check.
- Covered: instructor ownership; student authorization; question validation; publication without questions rejected; published questions frozen; answer keys withheld during active attempts; saved answers/resume; weighted scoring; submitted scores immutable; attempt limit; expiry rejects late answers; reports scoped to user; duplication/deletion; administrator deactivation; CSRF; registration cannot self-promote; repeatable schema preserves attempts.
- Browser automation passed: instructor draft creation, question creation, duration editing, student answering/autosave/submission with a verified 100% score, result history, registration returning to sign-in, and a 390px mobile layout without horizontal overflow. No frontend page errors were observed.
- Production dependencies: npm audit --omit=dev reported 0 vulnerabilities at delivery.
- Preview screenshots use isolated demonstration data, not the user’s database.
