const readline=require('readline/promises');
const bcrypt=require('bcryptjs');
const pool=require('../db');
(async()=>{const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{
 const full_name=(await rl.question('Full name: ')).trim();
 const email=(await rl.question('Email: ')).trim().toLowerCase();
 const role=(await rl.question('Role (admin/instructor): ')).trim();
 console.log('Password will be visible in this local terminal.');
 const password=await rl.question('New password (at least 8 characters): ');
 if(full_name.length<2||full_name.length>100||!/^\S+@\S+\.\S+$/.test(email)||email.length>254||!['admin','instructor'].includes(role)||password.length<8||Buffer.byteLength(password)>72)throw Error('Invalid account details.');
 await pool.query("INSERT INTO users(full_name,email,password_hash,role) VALUES($1,$2,$3,$4)",[full_name,email,await bcrypt.hash(password,12),role]);
 console.log('Account created. Existing accounts were not modified.');
}catch(e){console.error(e.code==='23505'?'Email already exists. Use the administrator Users page to change its role.':e.message);process.exitCode=1;}finally{rl.close();await pool.end();}})();
