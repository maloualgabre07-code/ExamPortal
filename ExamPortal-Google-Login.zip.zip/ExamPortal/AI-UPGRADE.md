# Install the AI upgrade

This upgrade is for the ExamPortal project previously provided. It adds Gemini question generation, editable instructor review, selection, and atomic saving to your existing PostgreSQL draft exam. No database migration or new npm package is required.

1. Stop the server in the VS Code terminal with Ctrl+C.
2. Back up your project folder.
3. Extract this ZIP. Copy app.js and ai.js into the folder containing package.json and server.js:
   C:\Users\Malou Algabre\OneDrive\ExamPortal\ExamPortal
4. Copy the supplied public/app.js and public/style.css into that project's public folder, replacing those two files. Keep public/index.html.
5. Keep your existing .env. Add these lines (replace the placeholder locally):

   GEMINI_API_KEY=YOUR_NEW_PRIVATE_KEY
   GEMINI_MODEL=gemini-3.5-flash-lite

   Revoke the key previously visible in your screenshot and create a replacement in Google AI Studio. Never put a key in public JavaScript. Do not share .env screenshots.
6. In the terminal inside the project root run:

   npm start

7. Open http://localhost:3000 and press Ctrl+F5 to reload the updated scripts.
8. Sign in as instructor. Go to Examinations, create a draft, then Manage questions. For a published exam, use Duplicate first.
9. Click Generate with AI. Enter a topic and optional lesson notes, select difficulty/type and 1–10 questions.
10. Review and edit each question, choices, correct answer, and points. Uncheck unwanted questions. Click Add selected questions to draft.
11. Check the question list. Publish separately when ready. Sign in as student to take the examination and view the saved results.

Example: topic Web Development Fundamentals; 10 questions; easy; multiple choice. Notes: HTML document structure, CSS styling, JavaScript events, Express routing, PostgreSQL primary and foreign keys.

Generation sends topic and lesson text to Google. AI may return incorrect content; an instructor must review it. Explanations, essays, AI proctoring, and class enrollment are not included in this upgrade.

Troubleshooting:
- No AI button: verify public/app.js was replaced in the inner project and press Ctrl+F5. Only editable drafts show it.
- Cannot find ./ai: ai.js must be next to app.js, not inside public.
- Missing key: save .env and restart the server.
- Key/model rejected: check your new key's Gemini access and the model available in AI Studio. Update GEMINI_MODEL if needed.
- Quota: check AI Studio limits or try later. Local app also permits 10 generation requests per instructor per hour, resetting on server restart.
- Network/timeout: check internet access to generativelanguage.googleapis.com; manual question entry remains available.

Validation: existing assessment integration tests and new AI authorization, draft-only access, invalid-response, quota, preview-without-saving, and bulk validation tests passed using a fake provider. Browser checks passed for generation preview, question editing, PostgreSQL save, existing instructor/student flows, and mobile page layout. Live Gemini generation has not been tested with your private key.

Official references checked October 6, 2026:
https://ai.google.dev/api/interactions-api
https://ai.google.dev/gemini-api/docs/structured-output
https://ai.google.dev/gemini-api/docs/pricing

Optional test files are included under test; copying them replaces the earlier integration test. Run npm test to verify locally (uses an isolated PostgreSQL-compatible test database, not your exam database).
