const path = require('path');
require('dotenv').config({path:path.join(__dirname,'.env'),quiet:true});
const {Pool}=require('pg');
const pool=new Pool({connectionTimeoutMillis:5000});
pool.on('error',e=>console.error('Database connection:',e.message));
module.exports=pool;
