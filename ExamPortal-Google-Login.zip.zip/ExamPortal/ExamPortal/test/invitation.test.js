const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');const path=require('path');
const {createApp}=require('../app');const {testPool}=require('./test-db');
test('Public registration allows students and instructors but not administrators',async t=>{
 const pool=await testPool();await pool.exec(fs.readFileSync(path.join(__dirname,'../schema.sql'),'utf8'));
 const service=createApp(pool,'test-session-secret-longer-than-thirty-two');
 const server=service.app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
 t.after(async()=>{service.close();await new Promise(r=>server.close(r));await pool.end();});
 const base=`http://127.0.0.1:${server.address().port}/api`;let cookie='',csrf='';
 async function call(url,method='GET',body){const r=await fetch(base+url,{method,headers:{Cookie:cookie,...(method!=='GET'?{'Content-Type':'application/json','X-CSRF-Token':csrf}:{})},...(method!=='GET'?{body:JSON.stringify(body)}:{})});if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];const d=await r.json();if(d.token)csrf=d.token;return{status:r.status,...d};}
 await call('/csrf');const body={full_name:'New Teacher',email:'new@example.com',password:'TeacherPass123!',role:'instructor'};
 assert.equal((await call('/register','POST',{...body,role:'admin'})).status,400);
 assert.equal((await pool.query('SELECT * FROM users')).rows.length,0);
 assert.equal((await call('/register','POST',body)).status,201);
 const login=await call('/login','POST',{email:body.email,password:body.password});assert.equal(login.status,200);assert.equal(login.user.role,'instructor');
 assert.equal((await call('/users')).status,403);assert.equal((await call('/exams')).status,200);
 assert.equal((await call('/register','POST',body)).status,409);
 assert.equal((await call('/register','POST',{full_name:'Student One',email:'student@example.com',password:'StudentPass123!'})).status,201);
 assert.equal((await call('/login','POST',{email:'student@example.com',password:'StudentPass123!'})).user.role,'student');
 assert.equal((await call('/bank')).status,403);
});
