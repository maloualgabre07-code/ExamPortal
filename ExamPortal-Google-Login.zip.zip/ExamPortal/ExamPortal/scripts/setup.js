const fs=require('fs');
const path=require('path');
const pool=require('../db');
(async()=>{try{await pool.query(fs.readFileSync(path.join(__dirname,'../schema.sql'),'utf8'));console.log('Database setup complete. Existing accounts and examinations were preserved.');}catch(e){console.error('Setup failed:',e.message);process.exitCode=1;}finally{await pool.end();}})();
