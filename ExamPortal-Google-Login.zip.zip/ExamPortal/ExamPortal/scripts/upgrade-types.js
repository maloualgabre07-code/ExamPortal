const fs=require('fs');const path=require('path');const pool=require('../db');
(async()=>{try{await pool.query(fs.readFileSync(path.join(__dirname,'../migrations/003-question-types.sql'),'utf8'));console.log('Question types upgraded. Existing examinations, accounts, and results preserved.');}catch(e){console.error('Upgrade failed:',e.message);process.exitCode=1;}finally{await pool.end();}})();
