# ExamPortal — start here

A complete classroom demonstration project using Node.js, Express, and PostgreSQL. The responsive interface includes student, instructor, and administrator workspaces. No external font, image, or CDN is required.

## Upgrade your existing project on Windows

1. In your current VS Code terminal, press Ctrl+C to stop the old server.
2. Make a backup copy of your entire Online Examination System folder. Keep that backup separate.
3. Extract this ZIP into a NEW folder named ExamPortal. Open this new folder in VS Code using File → Open Folder. This avoids accidentally keeping the old public/app.js or server.js.
4. Copy ONLY your existing `.env` file into the new ExamPortal folder, beside package.json. Keep its PostgreSQL password and SESSION_SECRET. The secret must contain at least 32 characters. Your existing secret generated earlier should meet this requirement. Do not share this file.
5. Open Terminal → New Terminal in the NEW folder and run:

```cmd
npm install
npm run setup
npm start
```

The setup script adds the required fields and tables. It does NOT drop or empty your existing users or exams. Existing drafts remain visible to their instructor. The database role must own the existing tables or have permission to alter them, as exam_user does in the setup used in this conversation.

6. Open http://localhost:3000. Sign in with your existing instructor@example.com account and the password you created earlier. Your dashboard now opens automatically after sign-in. Keep the server terminal running.

Do not copy the old exams.js into the new project; the new backend routes are in app.js. Use the new package.json, server.js, and entire public folder together. Old URLs such as instructor.html are replaced by the new unified dashboard at `/`.

## Administrator account

Open a SECOND VS Code terminal in the new folder. Run:

```cmd
npm run account
```

Enter your full name, a NEW email address, `admin` as the role, and a new password of at least 8 characters. The local terminal displays your password while typing; keep it private. This command creates a new account and does not reset or promote existing accounts.

Sign out of the website and sign in with this administrator account. Use Users to add instructors or students and to change another account's role or deactivate it. Deactivation preserves result history and blocks future requests from that user. You cannot deactivate yourself or change your own role from the Users page.

## Fresh installation

PostgreSQL must be installed and running. Create a database and an application role first. Copy `.env.example` to `.env`, fill in YOUR database connection values, and replace SESSION_SECRET with a random secret. In CMD, generate one with:

```cmd
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Paste the output as SESSION_SECRET in .env. Then run npm install, npm run setup, and npm run account to create an instructor or administrator. Students may register on the website.

## Complete demonstration flow

1. Instructor signs in → Examinations → Create examination.
2. Enter title, instructions, duration, passing threshold, attempt limit, and optional schedule.
3. Manage questions → Add question. Choose four-option multiple choice or two-option true/false. Select the correct option and points.
4. Test Edit and Delete on a temporary draft/question. Refresh to demonstrate database persistence.
5. Publish the real examination. Publication freezes its settings and questions. Duplicate creates a new editable draft, preserving old results.
6. Student registers/signs in → Available Exams → Start. The server checks availability, role, attempt count, and schedule.
7. Choose answers. Each change is saved; a periodic save retries every 10 seconds. The screen shows the last successful save. If the network fails, unsaved choices remain only on the open page; avoid refreshing until saving succeeds.
8. Submit → weighted automatic scoring → pass/below-threshold outcome → question review. The timer persists across reloads. Resume an existing attempt from Available Exams or My Results.
9. Instructor → Results & Reports → filter/search, inspect an attempt, export CSV, or print.
10. Administrator → Users and Activity Log. Change access and show recorded exam/account actions.

## Assessment rules

- 1–180 minutes; passing threshold 0–100%; 1–5 attempts; up to 100 questions per exam.
- Each question has 2 or 4 distinct options and 1–100 points. True/false uses two editable options.
- Score = sum of points for correctly answered questions. Unanswered or incorrect questions earn zero. The pass decision uses the exact score percentage; displayed percentages are rounded.
- Start opens or resumes one active attempt per exam/student. Starting consumes an attempt.
- Deadline is the earlier of start time + duration and the scheduled closing time.
- Server timestamps determine expiry. The browser clock cannot extend time. Answers arriving after the deadline are discarded; the server scores previously saved answers.
- Expiry is processed every 15 seconds while the server runs, during relevant requests, and on startup. Thus expired results remain correct after a server restart.
- Closing an exam blocks NEW attempts. Existing attempts keep their original deadlines.
- Published content stays immutable even after closing. Duplicate an exam to revise it.
- Completed attempts include answer review. Students who have multiple allowed attempts can use that feedback; choose one attempt if you do not want retakes after seeing correct answers.
- All published exams are available to all student accounts. Class enrollment, essays/manual marking, proctoring, question imports, emailed password recovery, and deployment are outside this release's scope.

## Features

- Responsive login/registration and role-aware navigation; validation and feedback.
- Password hashes, PostgreSQL session storage, CSRF tokens, JSON API validation, local login throttling, security headers.
- Instructor-owned exam CRUD; question CRUD; scheduling; publish/close/reopen; duplication.
- Student exam discovery; server-enforced timer; answer saving; resume; submission and expiry scoring.
- Student result history and answer review; instructor/admin result reports, search, CSV export, print.
- Administrator account creation, role management, account deactivation, and recent activity log.
- Profile name and password updates with current-password verification.
- Relational schema, foreign keys, constraints, transaction handling, snapshots for result integrity, and controlled error responses.

## Project files

- `server.js`: start server, verify setup, process expired attempts.
- `app.js`: API routes, authentication, authorization, examination processing.
- `db.js`: PostgreSQL pool and environment configuration.
- `schema.sql`: additive/idempotent schema setup.
- `scripts/setup.js`: apply schema to PostgreSQL.
- `scripts/account.js`: create privileged account locally.
- `public/index.html`, `style.css`, `app.js`: modern application interface.
- `test/`: repeatable integration tests with PGlite, an in-process PostgreSQL engine. Runtime uses your real PostgreSQL server through pg.

## Testing

```cmd
npm test
```

The tests create an isolated in-memory database and never use or modify your configured PostgreSQL database. They verify registration role restrictions, CSRF, user roles, ownership restrictions, exam creation/publishing, invalid questions, weighted scoring, saving/resume, post-submission immutability, attempt limits, expiry, duplication/deletion, user deactivation, reporting scope, and repeatable migrations.

Browser automation also checked instructor draft creation/question creation/editing and mobile layout during delivery. Test results are included in VALIDATION.md. You still need to run setup and demonstrate the system against your installed PostgreSQL; this package cannot inspect your laptop.

## Troubleshooting

- `Cannot find module`: run npm install in the extracted folder; keep all package files together.
- `Startup failed` with missing column/table: run npm run setup.
- `password authentication failed`: check PGUSER and PGPASSWORD in .env. Use your database role's password, not the website password.
- `relation users does not exist`: run setup against the intended PGDATABASE.
- `address already in use`: stop the old node server with Ctrl+C before starting the upgrade.
- `localhost refused to connect`: check the terminal, run npm start, and leave it running.
- `Session verification failed`: refresh the page; use the same hostname throughout. Do not mix localhost with 127.0.0.1.
- Change your Windows timezone/date if displayed schedules are wrong. The server stores timestamps with timezone.

This is a local classroom demonstration release. It binds to 127.0.0.1. Public hosting requires its own HTTPS/session/proxy configuration and deployment review; do not simply expose the development server. There are no hardcoded default accounts or passwords.
